This software is provided to evaluate the method described in the paper
"Effective Compression of Range Data Streams for Remote Robot Operations using H.264"
from Fabrizio Nenci, Luciano Spinello and Cyrill Stachniss



=== Citations ====
In case you use this software in a research of yours, please cite the article.
A bibtex entry with the main details follows.

@INPROCEEDINGS{nenciIROS14,
   Author = {F. Nenci and L. Spinello and C. Stachniss},
   Title = {Effective Compression of Range Data Streams for Remote Robot Operations using H.264},
   Booktitle = {Proc. of The International Conference on Intelligent Robots and Systems (IROS)},
   Year = {2014}
}



==== C++ Library Coming Soon ====
The currently provided software is shipped in order to make it possible to
reproduce the quality of the results described in the paper in terms of quality
of the reconstructed images.
As it creates and saves on the disk a large amount of images, and uses the 'x264'
and 'ffmpeg' commands as external tools, the time performances are not comparable
with those described in the paper.
In order to get realtime performances the C libraries provided by x264 and FFmpeg
have to be included in your own code.
It is our intention to release a easily usable interface to use our method as a
C++ library, so to allow for an effective use of the method in real-life use cases.
The library will be released as soon as it will be ready.



==== Software Copyright ====
Copyright (C) 2014 Fabrizio Nenci and Luciano Spinello and Cyrill Stachniss

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.



==== Example Dataset ====
The example dataset provided is the "freiburg1_desk" dataset that can be
downloaded from the "Technische Universität München" Computer Vision Group
rgbd dataset download page at:
http://vision.in.tum.de/data/datasets/rgbd-dataset/download
The shipped version has been preprocessed in such a way that one depth unit
corresponds to a millimiter.



==== Example Dataset License ====
The dataset is released under Creative Commons 3.0 Attribution License (CC-BY 3.0).
For a short description of this license, see:
https://creativecommons.org/licenses/by/3.0/
And for the license itself see:
https://creativecommons.org/licenses/by/3.0/legalcode



==== Other Datasets ====
For the experiments described in the paper, we used:
11 of the datasets at http://vision.in.tum.de/data/datasets/rgbd-dataset/download
the 3 datasets available at http://www2.informatik.uni-freiburg.de/~spinello/RGBD-dataset.html
and a non-public dataset from the Catacombs in Rome (Rovina Project).



==== Compile and Run ====
See the "RUNNING.txt" file.

