// DSL - Depth Streaming Library, a software for streaming depth images sequences
// Copyright (C) 2014 Fabrizio Nenci and Luciano Spinello and Cyrill Stachniss

// This file is part of DSL

// DSL is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// DSL is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with DSL.  If not, see <http://www.gnu.org/licenses/>.


#ifndef _LAYERS_MERGER_H
#define _LAYERS_MERGER_H

#include <vector>

namespace ds
{	
	// this class computes depth images putting together the layers composing those images.
	class LayersMerger
	{
		private:
			const unsigned int _rows;
			const unsigned int _cols;
			const unsigned int _totalCells;
			const unsigned int _outputLength;
			unsigned int * _r_idx;	// indices of the rows when accessing an image in the form of an array
			std::vector<unsigned short *> _lookupValues;	// these lookup arrays map values in [0,255] to whatever interval is covered by the corresponding layer
			void prepareLookupValues(std::vector< std::pair<unsigned short, unsigned short> > & intervals);	// generates and populates the lookup tables
			
		public:
			// the intervals are supposed to be couples of [near cut, far cut] values, and they are expected to be in ascending order (the first interval is the closest)
			LayersMerger(std::vector< std::pair<unsigned short, unsigned short> > & intervals, unsigned int rows, unsigned int cols);
			LayersMerger(ds::LayersMerger &);
			~LayersMerger();

			void merge(unsigned char * idmap, std::vector< unsigned char * > & layers, unsigned short * output);
	};


}


#endif	// _LAYERS_MERGER_H
