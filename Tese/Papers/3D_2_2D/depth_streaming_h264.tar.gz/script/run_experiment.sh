#!/bin/bash
## This program shows how to create a pipeline that:
## 	• divides the input depth images into layers
## 	• encodes every layer separately in videos using a specified quality profile
## 	• decodes every video
## 	• uses the decoded layers to recompute the images
##
## input:
## 	input_folder		-- folder containing the 16 bit depth images (.png files)
##	layers_folder		-- folder where to create the subfolders with the images of the individual layers
## 	video_folder 		-- folder where to create the video files
## 	decode_folder		-- folder where to put the images of the layers decoded from the videos
## 	reconstruction_folder	-- folder where to put the reconstructed images
## 	min_cut			-- smaller interesting depth value
## 	max_cut			-- bigger interesting depth value
## 	layers_number		-- layers to be used to cover the interesting interval
## 	quality_profile		-- quality profile to be used to encode the layers

#
# Copyright (C) 2014 Fabrizio Nenci and Luciano Spinello and Cyrill Stachniss
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

if [ $# -lt 9 ]
then
	echo "";
	echo "Usage: ${0##*/} <input_folder> <layers_folder> <videos_folder> <decode_folder> <reconstruction_folder> <min_cut> <max_cut> <layers_number> <quality_profile>";
	echo "";
	echo "read the script for further details on the inputs";
	exit 0;
fi

in_fold=$1;
lay_fold=$2;
video_fold=$3;
deco_fold=$4;
reco_fold=$5;
min_cut=$6;
max_cut=$7;
layers_num=$8;
qp=$9;

# prune tailing slashes from the folders names
while [ ${in_fold:${#in_fold}-1} = '/' ]; do in_fold=${in_fold:0:${#in_fold}-1}; done
while [ ${lay_fold:${#lay_fold}-1} = '/' ]; do lay_fold=${lay_fold:0:${#lay_fold}-1}; done
while [ ${video_fold:${#video_fold}-1} = '/' ]; do video_fold=${video_fold:0:${#video_fold}-1}; done

# display settings
echo "";
echo "in_fold: $in_fold";
echo "lay_fold: $lay_fold";
echo "video_fold: $video_fold";
echo "deco_fold: $deco_fold";
echo "reco_fold: $reco_fold";
echo "min_cut: $min_cut";
echo "max_cut: $max_cut";
echo "layers_num: $layers_num";
echo "qp: $qp";
echo "";


lay_digits=1;
pow=10;
while [ $pow -lt $layers_num ]
do
	(( lay_digits ++ ));
	(( pow = 10 ** $lay_digits ));
done
unset pow;

dset_name=${in_fold##*/};
lay_base_name=${lay_fold}/${dset_name}

# divide the images into layers
./images_exploder ${in_fold} $lay_base_name -l $min_cut $max_cut $layers_num;


# encode and decode
./encode_and_decode_layers.sh $lay_base_name $video_fold $deco_fold $layers_num $qp


# reconstruct the images from the layers
./images_reconstruction ${deco_fold}/${dset_name} $reco_fold;
